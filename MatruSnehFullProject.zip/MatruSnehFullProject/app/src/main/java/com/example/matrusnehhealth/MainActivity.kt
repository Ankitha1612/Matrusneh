
package com.example.matrusnehhealth

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppScreen()
        }
    }
}

@Composable
fun AppScreen() {
    var kicks by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text("Matru-Sneh Health", fontSize = 30.sp)

        Spacer(modifier = Modifier.height(20.dp))

        Text("Pregnancy Week: 24")
        Text("Health Status: Good")

        Spacer(modifier = Modifier.height(20.dp))

        Text("Baby Kick Counter", fontSize = 22.sp)

        Text("$kicks kicks", fontSize = 20.sp)

        Button(onClick = { kicks++ }) {
            Text("Baby Kick +1")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("Nutrition Checklist", fontSize = 22.sp)

        Row {
            Checkbox(checked = true, onCheckedChange = {})
            Text("Water")
        }

        Row {
            Checkbox(checked = true, onCheckedChange = {})
            Text("Fruits")
        }

        Row {
            Checkbox(checked = false, onCheckedChange = {})
            Text("Medicines")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(onClick = {}) {
            Text("Emergency Alert")
        }
    }
}
