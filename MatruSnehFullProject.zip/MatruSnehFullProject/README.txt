
1. Open Android Studio
2. Click Open
3. Select project folder
4. Wait for Gradle sync
5. Connect phone with USB debugging ON
6. Click Run ▶
